# Photos for the guides

Put photos in this folder using the file names below. A photo appears automatically under its step once a file with the right name is here. Until then, nothing shows for that step. Images can be `.jpg` and roughly 1000–1600 px on the long side; landscape works best.

Before you upload a photo, crop or blur any **serial numbers, product keys, QR codes on drive labels, or anything personal** in it. Removing location data (EXIF) is also a good idea. Many phone gallery apps can do this when sharing.

## HP Envy 17

| File name | Step |
|---|---|
| `envy-bottom-screws.jpg` | Phase 1: bottom-cover screw locations |
| `envy-antenna-cover.jpg` | Phase 5: black cover over the Wi-Fi antenna connectors |
| `envy-antenna-label-nm00.jpg` | Phase 5: antenna label DC33002NM00 (included) |
| `envy-antenna-label-nm10.jpg` | Phase 5: antenna label DC33002NM10 (included) |
| `envy-wifi-card-main-aux.jpg` | Phase 5: MAIN and AUX labels on the Wi-Fi card |
| `envy-lid-hinge-mount-broken.jpg` | Phase 6: the broken hinge mount in the old lid |
| `envy-old-lid-inside.jpg` | Phase 7: inside of the old lid, antenna and cable routing |
| `envy-antennas-reconnected.jpg` | Phase 9: antennas reconnected on the Wi-Fi card |

## Toshiba U845W

| File name | Step |
|---|---|
| `toshiba-bottom-screws.jpg` | Phase 2: bottom-cover screws |
| `toshiba-inside.jpg` | Phase 3: inside view (drive, memory, battery) |
| `toshiba-left-hinge.jpg` | Phase 4: the clicking left hinge and its mount |
| `toshiba-coating-before.jpg` | Phase 5: sticky coating before cleaning |
| `toshiba-coating-after.jpg` | Phase 5: after stripping the coating |

## External drives

| File name | Step |
|---|---|
| `drives-hp-adapter-board.jpg` | Phase 1: the HP adapter board on the 500GB drive |

## Adding a photo to another step

Copy an existing `<div class="photos">…</div>` block in `index.html`. Paste it just before the `</li>` of the step you want, then change the file name and caption.
